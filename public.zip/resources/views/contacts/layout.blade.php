<!DOCTYPE html>
<html>
<head>
    <title>Contact Laravel 8 CRUD</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
</head>
<body>
<!-- Header Area -->
<div class="container bg-info" style="background-color: green">
    <h1><a href="http://127.0.0.1:8000/contact">CURD Header</a></h1>
</div>

  
<div class="container">
    @yield('content')
</div>

<!-- Footeer Area -->
<div class="container " style="background-color: green">
    <h1>CURD Footeer</h1>
</div>
   
</body>
</html>